var  dia

dia=  parseInt(prompt("Digite um numero correspondente ao dia da semana"))

switch(dia){
    case 1:
        {
            alert("Domingo")
            break
        }
    case 2:
        {
            alert("Segunda-feira")
            break
        }
    case 2:
        {
            alert("Terça-feira")
            break
        }
    case 3:
        {
            alert("Quarta-feira")
            break
        }
    case 4:
        {
            alert("Quinta-feira")
            break
        }
    case 5:
        {
             alert("Sexta-feira")
             break
        }
    case 6:
        {
            alert("Sábado")
            break
        }
    default:{
            alert("Opção inválida")
    }
}

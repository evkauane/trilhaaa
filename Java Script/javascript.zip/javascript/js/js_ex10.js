var v=[4,8,7,6]
//alert(v)

v[1]=20
//alert(v[2])
var lista
lista=["Zeca", 1880, "Rua Pedro Koppe","Irati", "PR", 80.5, true]
alert(lista)
lista.push("84500-000") //adiciona um elemento ao final da lista
alert(lista)
lista.push("teste")
alert(lista)
lista.pop() //remove o ultimo elemento da lista
alert(lista)